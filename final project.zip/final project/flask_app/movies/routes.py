import requests
from flask import Blueprint, render_template, url_for, current_app, redirect, request
from flask_login import current_user
from flask_app.main.utils import watch_list_shows


movies = Blueprint("movies", __name__)

@movies.route("/movie")

@movies.route("/movie/<int:movie_id>")
def current_movie(movie_id):
    movie_url = f"{current_app.config['URL']}movie/{movie_id}?api_key={current_app.config['API_KEY']}&language=en-US"
    movie_data = requests.get(movie_url).json()
    return render_template("current_movie.html", title=movie_data['title'], movie=movie_data)
