from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from .config import Config
from dotenv import load_dotenv
import os

from flask_login import UserMixin
load_dotenv()


db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
URL = 'https://api.themoviedb.org/3/'
API_KEY = "f008a46af7cf3387a27502d273a9c5d6"

def create_app(config_class=Config):
    SECRET_KEY = os.urandom(32)
    app = Flask(__name__)
    app.app_context().push()
    app.config['URL'] = URL
    app.config['API_KEY'] = API_KEY
    app.config["SQLALCHEMY_DATABASE_URI"] = SQLALCHEMY_DATABASE_URI
    db.init_app(app)
    db.create_all()
    bcrypt.init_app(app)
    app.config['SECRET_KEY'] = SECRET_KEY
    login_manager.init_app(app)


    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    class User(db.Model, UserMixin):
        id = db.Column(db.Integer, primary_key=True)
        email = db.Column(db.String, unique=True, nullable=False)
        username = db.Column(db.String, nullable=False)
        password = db.Column(db.String(400), nullable=False)
        watchlist = db.relationship("WatchList", backref="user", lazy=True)

        def __repr__(self):
            return f"<User {self.email}>"

    class WatchList(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        movie = db.Column(db.Integer)
        show = db.Column(db.Integer)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)


    from .main.routes import main
    app.register_blueprint(main)

    from .movies.routes import movies
    app.register_blueprint(movies)

    from .shows.routes import tv
    app.register_blueprint(tv)

    from .users.routes import user
    app.register_blueprint(user)
    
    return app

